version: 25'000
date: 2020-11-26
author: jérémie
------------------------------------------------------
cerbytesdb = encrypted(256)
cerbytesdb2 = not encrypted (test purpose, debugging)

